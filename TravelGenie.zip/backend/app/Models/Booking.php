<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    /**
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'tour_id',
        'booking_date',
        'num_adults',
        'num_children',
        'total_price',
        'customer_name',
        'customer_email',
        'status',
    ];
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    
    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }
    public function review()
    {
        return $this->hasOne(Review::class);
    }
}
