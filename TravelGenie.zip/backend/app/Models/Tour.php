<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tour extends Model
{
    use HasFactory;

    /**
     * @var array
     */
    protected $fillable = [
        'user_id',
        'title',
        'location',
        'category',
        'duration',
        'price',
        'rating',
        'highlights',
        'itinerary',
        'image_url',
        'coords',
    ];

    /**
     * @var array
     */
    protected $casts = [
        'highlights' => 'array',
        'itinerary' => 'array',
        'coords' => 'array',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function reviews()
    {
        return $this->hasMany(Review::class);
    }
    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }
}
