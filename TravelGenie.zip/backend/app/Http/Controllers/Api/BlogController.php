<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Blog; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage; 

class BlogController extends Controller
{

    public function showByDivision($division)
    {
        return Blog::where('division', $division)->orderBy('date', 'desc')->get();
    }


    
    
    
    


    public function index()
    {
        return Blog::orderBy('title')->get();
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'division' => 'required|string|max:255',
            'author' => 'required|string|max:255',
            'date' => 'required|date',
            'content' => 'required|string',
            'images' => 'required|array|min:1', 
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048', 
        ]);

        $imagePaths = [];
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $file) {
                $path = $file->store('blogs', 'public');
                $url = Storage::disk('public')->url($path);

                
                
                $imagePaths[] = $url . '?v=' . time();
                
            }
        }

        $blog = Blog::create([
            'title' => $validated['title'],
            'division' => $validated['division'],
            'author' => $validated['author'],
            'date' => $validated['date'],
            'content' => $validated['content'],
            'images' => $imagePaths, 
        ]);

        return response()->json($blog, 201);
    }
    public function destroy(Blog $blog)
    {
        
        if (is_array($blog->images)) {
            foreach ($blog->images as $imageUrl) {
                
                $pathToDelete = str_replace(asset('storage/'), '', $imageUrl);
                Storage::disk('public')->delete($pathToDelete);
            }
        }

        $blog->delete();

        return response()->json(['message' => 'Blog post deleted successfully.']);
    }
}
