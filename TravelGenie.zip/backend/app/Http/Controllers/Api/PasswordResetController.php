<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

class PasswordResetController extends Controller
{

    public function verifySecurityAnswer(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
            'security_question' => 'required|string',
            'security_answer' => 'required|string',
        ]);

        $user = User::where('email', $request->email)->first();

        
        if ($user->security_question !== $request->security_question) {
            return response()->json(['message' => 'Security question does not match.'], 422);
        }

        
        if (!Hash::check($request->security_answer, $user->security_answer)) {
            return response()->json(['message' => 'Security answer is incorrect.'], 422);
        }

        
        $token = Str::random(60);
        Cache::put('password_reset_token_' . $user->id, $token, now()->addMinutes(10));

        return response()->json([
            'message' => 'Verification successful. You can now set a new password.',
            'reset_token' => $token, 
        ]);
    }
   

    public function resetPasswordWithToken(Request $request)
    {
        $request->validate([
            'token' => 'required|string',
            'email' => 'required|email|exists:users,email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = User::where('email', $request->email)->first();

        $storedToken = Cache::get('password_reset_token_' . $user->id);

        
        if (!$storedToken || $storedToken !== $request->token) {
            return response()->json(['message' => 'Invalid or expired reset token.'], 422);
        }

        
        $user->password = Hash::make($request->password);
        $user->save();

        Cache::forget('password_reset_token_' . $user->id);

        return response()->json(['message' => 'Password has been reset successfully. You can now log in.']);
    }
}
