<?php

namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;
use App\Models\Tour; 
use App\Models\Booking;
use Illuminate\Http\Request;

class TourController extends Controller
{

    public function index()
    {
        
        
        return Tour::with(['reviews.user', 'user'])->get();
    }
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'location' => 'required|string|max:255',
            'category' => 'required|string|max:255',
            'duration' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'rating' => 'numeric|min:0|max:5',
            'highlights' => 'required|string', 
            'coords' => 'required|string',   
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048' 
        ]);

        $user = $request->user();
        $imageUrl = null;

        if ($request->hasFile('image')) {
            $path = $request->file('image')->store('tours', 'public');
            $imageUrl = Storage::disk('public')->url($path);
        }

        $tourData = $validated;
        $tourData['image_url'] = $imageUrl;
        $tourData['highlights'] = json_decode($validated['highlights']);
        $tourData['coords'] = json_decode($validated['coords']);
        $tourData['itinerary'] = [];

        $tour = $user->tours()->create($tourData);

        return response()->json($tour, 201);
    }

    

    public function update(Request $request, Tour $tour)
    {
        $user = $request->user();
        /** @var \App\Models\User $user */

        
        if ($user->role !== 'administrator' && $tour->user_id !== $user->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'location' => 'required|string|max:255',
            'category' => 'required|string|max:255',
            'duration' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'rating' => 'required|numeric|min:0|max:5',
            'highlights' => 'required|array',
        ]);

        
        
        
        
        

        $tour->update($validated);

        return response()->json($tour);
    }
    public function destroy(Request $request, Tour $tour)
    {
        $user = $request->user();
        /** @var \App\Models\User $user */

        
        if ($user->role !== 'administrator' && $tour->user_id !== $user->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $tour->delete();

        return response()->json(['message' => 'Tour deleted successfully.']);
    }
    public function myTours(Request $request)
    {
        $user = $request->user();
        
        $tours = $user->tours()->withCount('bookings')->with('bookings.user')->latest()->get();
        return response()->json($tours);
    }
}
