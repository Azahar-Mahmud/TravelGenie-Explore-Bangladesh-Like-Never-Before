<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Tour;

class WishlistController extends Controller
{
    
    public function index(Request $request)
    {
        return $request->user()->wishlistedTours()->with('user')->get();
    }

    
    public function toggle(Request $request, Tour $tour)
    {
        $user = $request->user();

        
        $result = $user->wishlistedTours()->toggle($tour->id);

        
        if (count($result['attached']) > 0) {
            return response()->json(['status' => 'added', 'message' => 'Tour added to wishlist.']);
        } else {
            return response()->json(['status' => 'removed', 'message' => 'Tour removed from wishlist.']);
        }
    }
}
