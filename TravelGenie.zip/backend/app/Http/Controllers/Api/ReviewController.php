<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Review;
use App\Models\Tour;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    
    public function store(Request $request, Booking $booking)
    {
        $user = $request->user();

        
        if ($user->id !== $booking->user_id) {
            return response()->json(['message' => 'Unauthorized.'], 403);
        }

        
        if ($booking->status !== 'completed') {
            return response()->json(['message' => 'You can only review completed tours.'], 403);
        }

        
        if ($booking->review()->exists()) {
            return response()->json(['message' => 'You have already reviewed this booking.'], 403);
        }

        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'required|string|min:10',
        ]);

        
        $review = $booking->review()->create([
            'user_id' => $user->id,
            'tour_id' => $booking->tour_id, 
            'rating' => $request->rating,
            'comment' => $request->comment,
        ]);

        
        $tour = $booking->tour;
        $tour->rating = $tour->reviews()->avg('rating');
        $tour->save();

        return response()->json(['message' => 'Review submitted successfully!', 'review' => $review->load('user')], 201);
    }
}
