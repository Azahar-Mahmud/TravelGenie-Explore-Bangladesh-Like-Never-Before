<?php

namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Tour;
use App\Models\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    
    public function getUsers()
    {
        return User::orderBy('name')->get();
    }
    public function updateUserRole(Request $request, User $user)
    {
        $request->validate([
            'role' => 'required|in:traveler,business_owner,administrator'
        ]);

        $user->role = $request->role;
        $user->save();

        return response()->json(['message' => 'User role updated successfully.', 'user' => $user]);
    }
    public function destroyUser(Request $request, User $user)
    {
        
        if ($request->user()->id === $user->id) {
            return response()->json(['message' => 'You cannot delete your own account.'], 403);
        }

        
        if ($user->role === 'administrator') {
            return response()->json(['message' => 'Administrator accounts cannot be deleted.'], 403);
        }

        
        $user->delete();

        return response()->json(['message' => 'User deleted successfully.']);
    }
    
    public function getAllTours()
    {
        return Tour::with('user')->orderBy('title')->get();
    }

    public function getAllBookings()
    {
        
        return Booking::with(['user', 'tour.user'])->latest()->get();
    }

    public function updateBookingStatus(Request $request, Booking $booking)
    {
        $request->validate(['status' => 'required|in:pending,confirmed,completed,cancelled']);
        $booking->status = $request->status;
        $booking->save();
        return response()->json(['message' => 'Booking status updated.', 'booking' => $booking]);
    }
    public function destroyBooking(Booking $booking)
    {
        $booking->delete();
        return response()->json(['message' => 'Booking deleted successfully.']);
    }
}
