<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class BookingController extends Controller
{

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'tour_id' => 'required|exists:tours,id',
            'booking_date' => 'required|date|after_or_equal:today',
            'num_adults' => 'required|integer|min:1',
            'num_children' => 'required|integer|min:0',
            'total_price' => 'required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $bookingData = $validator->validated();
        $user = $request->user();

        $bookingData['user_id'] = $user->id;
        $bookingData['customer_name'] = $user->name;
        $bookingData['customer_email'] = $user->email;

        $booking = Booking::create($bookingData);

        return response()->json(['message' => 'Booking created successfully!', 'booking' => $booking], 201);
    }

    
    public function userBookings(Request $request)
    {
        $bookings = $request->user()
            ->bookings()
            
            ->with(['tour', 'review'])
            ->latest()
            ->get();

        
        $bookings->each(function ($booking) {
            $booking->reviewed = $booking->review !== null;
        });

        return response()->json($bookings);
    }

    public function cancel(Request $request, Booking $booking)
    {
        $user = $request->user();

        if ($booking->user_id !== $user->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }
        if (!in_array($booking->status, ['pending', 'confirmed'])) {
            return response()->json(['message' => 'This booking cannot be cancelled.'], 422);
        }
        $booking->status = 'cancelled';
        $booking->save();
        return response()->json(['message' => 'Booking cancelled successfully!', 'booking' => $booking]);
    }

    public function simulatePayment(Request $request, Booking $booking)
    {
        $user = $request->user();

        if ($booking->user_id !== $user->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }
        $booking->status = 'confirmed';
        $booking->save();
        return response()->json(['message' => 'Payment successful! Your booking is confirmed.', 'booking' => $booking]);
    }
}
