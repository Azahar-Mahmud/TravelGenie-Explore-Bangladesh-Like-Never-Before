function mainPageData() {
    return {
        isSignupOpen: false,
        isLoginOpen: false,
        isDivisionModalOpen: false,
        isProfileErrorOpen: false,
        isForgotPasswordOpen: false,
        isSetNewPasswordOpen: false,
        isBlogPostModalOpen: false,
        isProfileDropdownOpen: false,
        activeDivisionId: 'dhaka',
        activeDivision: {},
        activeBlogPost: null,
        activeDivisionBlogs: [],

        signupForm: { name: '', email: '', password: '', role: 'traveler', security_question: '', security_answer: '', status: '' },
        loginForm: { email: '', password: '', status: '' },
        resetForm: { email: '', security_question: '', security_answer: '', password: '', password_confirmation: '', token: '', status: '' },


        get isModalOpen() {
            return this.isSignupOpen || this.isLoginOpen || this.isDivisionModalOpen || this.isProfileErrorOpen || this.isForgotPasswordOpen || this.isSetNewPasswordOpen || this.isBlogPostModalOpen;
        },

        closeAllModals() {
            this.isSignupOpen = false;
            this.isLoginOpen = false;
            this.isDivisionModalOpen = false;
            this.isProfileErrorOpen = false;
            this.isForgotPasswordOpen = false;
            this.isSetNewPasswordOpen = false;
            this.isBlogPostModalOpen = false;
            this.activeBlogPost = null;
            this.isProfileDropdownOpen = false;
            this.resetForm = { email: '', security_question: '', security_answer: '', password: '', password_confirmation: '', token: '', status: '' };
        },
        
        showDivisionDetails() {
            if (this.activeDivisionId && Alpine.store('divisions').data[this.activeDivisionId]) {
                this.activeDivision = Alpine.store('divisions').data[this.activeDivisionId];
                this.isDivisionModalOpen = true;
                this.fetchBlogsForDivision(this.activeDivisionId);
            }
        },

        openBlogPostModal(post) {

    this.activeBlogPost = post;
    this.isBlogPostModalOpen = true;
},
        async fetchBlogsForDivision(divisionSlug) {
    this.activeDivisionBlogs = []; 
    try {
        const response = await fetch(`http://127.0.0.1:8000/api/blogs/${divisionSlug}`);
        if (!response.ok) {
            throw new Error('Could not load blog posts.');
        }
        this.activeDivisionBlogs = await response.json();
    } catch (error) {
        console.error(error);
        this.activeDivisionBlogs = [];
    }
},
        async handleRegister() {
            this.signupForm.status = 'Registering...';
            try {
                const response = await fetch('http://127.0.0.1:8000/api/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                    body: JSON.stringify(this.signupForm)
                });
                const result = await response.json();
                if (!response.ok) {
                    const errorMessages = Object.values(result.errors || { error: [result.message] }).flat().join(' ');
                    throw new Error(errorMessages);
                }
                this.signupForm.status = 'Success! You can now log in.';
                setTimeout(() => { 
                    this.closeAllModals(); 
                    this.signupForm = { name: '', email: '', password: '', role: 'traveler', security_question: '', security_answer: '', status: '' }; 
                }, 2000);
            } catch (error) {
                this.signupForm.status = `Error: ${error.message}`;
            }
        },

        async handleLogin() {
            this.loginForm.status = 'Logging in...';
            try {
                const response = await fetch('http://127.0.0.1:8000/api/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                    body: JSON.stringify(this.loginForm)
                });
                const data = await response.json();
                if (!response.ok) {
                    throw new Error(data.message || 'Invalid credentials.');
                }
                Alpine.store('auth').login(data.user, data.token);
                this.loginForm.status = '';
                this.closeAllModals();
                this.loginForm = { email: '', password: '', status: '' };
            } catch (error) {
                this.loginForm.status = `Error: ${error.message}`;
            }
        },

        async handleVerifyAnswer() {
            this.resetForm.status = 'Verifying...';
            try {
                const response = await fetch('http://127.0.0.1:8000/api/password/verify-answer', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                    body: JSON.stringify(this.resetForm)
                });
                const result = await response.json();
                if (!response.ok) { throw new Error(result.message); }
                
                this.resetForm.token = result.reset_token;
                this.resetForm.status = '';
                this.isForgotPasswordOpen = false;
                this.isSetNewPasswordOpen = true;
            } catch (error) {
                this.resetForm.status = `Error: ${error.message}`;
            }
        },

        async handleResetPassword() {
            this.resetForm.status = 'Resetting password...';
            try {
                const response = await fetch('http://127.0.0.1:8000/api/password/reset-with-token', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                    body: JSON.stringify(this.resetForm)
                });
                const result = await response.json();
                if (!response.ok) { throw new Error(result.message); }
                
                this.resetForm.status = result.message;
                setTimeout(() => { this.closeAllModals(); }, 3000);
            } catch (error) {
                this.resetForm.status = `Error: ${error.message}`;
            }
        },

        async handleLogout() {
             await fetch('http://127.0.0.1:8000/api/logout', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${Alpine.store('auth').token}`,
                    'Accept': 'application/json'
                }
            });
            Alpine.store('auth').logout();
        }
    };
}
function initContactMap() {
    const officeLocation = { lat: 23.770487712574948, lng: 90.42594708984369 };

    const mapElement = document.getElementById('contact-map');
    if (!mapElement || typeof google === 'undefined') {
        console.error("Google Maps not loaded or map element not found.");
        if(mapElement) mapElement.innerHTML = "<div class='flex items-center justify-center h-full text-gray-400'>Map could not be loaded.</div>";
        return;
    }

    const mapStyle = [ { "featureType": "all", "elementType": "labels.text.fill", "stylers": [ { "color": "#ffffff" } ] }, { "featureType": "all", "elementType": "labels.text.stroke", "stylers": [ { "color": "#000000" }, { "lightness": 13 } ] }, { "featureType": "administrative", "elementType": "geometry.fill", "stylers": [ { "color": "#000000" } ] }, { "featureType": "administrative", "elementType": "geometry.stroke", "stylers": [ { "color": "#144b53" }, { "lightness": 14 }, { "weight": 1.4 } ] }, { "featureType": "landscape", "elementType": "all", "stylers": [ { "color": "#08304b" } ] }, { "featureType": "poi", "elementType": "geometry", "stylers": [ { "color": "#0c4152" }, { "lightness": 5 } ] }, { "featureType": "road.highway", "elementType": "geometry.fill", "stylers": [ { "color": "#000000" } ] }, { "featureType": "road.highway", "elementType": "geometry.stroke", "stylers": [ { "color": "#0b434f" }, { "lightness": 25 } ] }, { "featureType": "road.arterial", "elementType": "geometry.fill", "stylers": [ { "color": "#000000" } ] }, { "featureType": "road.arterial", "elementType": "geometry.stroke", "stylers": [ { "color": "#0b3d51" }, { "lightness": 16 } ] }, { "featureType": "road.local", "elementType": "geometry", "stylers": [ { "color": "#000000" } ] }, { "featureType": "transit", "elementType": "all", "stylers": [ { "color": "#146474" } ] }, { "featureType": "water", "elementType": "all", "stylers": [ { "color": "#021019" } ] } ];

    const map = new google.maps.Map(mapElement, {
        center: officeLocation,
        zoom: 15,
        styles: mapStyle,
        disableDefaultUI: true
    });

    new google.maps.Marker({
        position: officeLocation,
        map: map,
        title: "TravelGenie Headquarters"
    });
}
document.addEventListener('alpine:init', () => {

    Alpine.store('divisions', {
    data: {
        dhaka: {
            title: "Dhaka",
            description: "The bustling capital city, heart of the nation's commerce, culture, and education. Known for its rich history and vibrant street life.",
            longDescription: "Dhaka is a megacity teeming with energy. Explore historical landmarks like Lalbagh Fort and Ahsan Manzil, get lost in the vibrant chaos of Old Dhaka's narrow streets, and savor the world-renowned Mughlai cuisine. It's a city of rickshaws, markets, and endless stories.",
            imageUrl:"img/divisions/dhaka-card.jpg",
        },
        chittagong: {
            title: "Chittagong",
            description: "Home to the country's largest port and beautiful natural scenery, including Cox's Bazar, the world's longest natural sea beach.",
            longDescription: "Chittagong offers a diverse landscape, from the bustling port city to the serene hills of the Hill Tracts. It's the gateway to stunning beaches like Cox's Bazar and St. Martin's Island, making it a hub for both commerce and natural beauty.",
            imageUrl: "img/divisions/chittagong-card.jpg",
        },
        rajshahi: {
            title: "Rajshahi",
            description: "Known as the 'Silk City,' famous for its high-quality silk production, delicious mangoes, and ancient archaeological sites.",
            longDescription: "Rajshahi is renowned for its archaeological treasures, including the Puthia Temple Complex and the ancient ruins of Mahasthangarh. The region is also celebrated for its sweet mangoes and the production of exquisite silk.",
            imageUrl: "img/divisions/rajshahi-card.jpg",
        },
        khulna: {
            title: "Khulna",
            description: "Gateway to the Sundarbans, the world's largest mangrove forest and a UNESCO World Heritage site, home of the Royal Bengal Tiger.",
            longDescription: "Khulna is your entry point to the majestic Sundarbans. This unique mangrove ecosystem is a UNESCO World Heritage Site and one of the last remaining habitats of the Royal Bengal Tiger. Explore its winding rivers and dense forests by boat for a true adventure.",
            imageUrl: "img/divisions/khulna-card.jpg",
        },
        barisal: {
            title: "Barisal",
            description: "Known as the 'Venice of the East' for its intricate network of rivers, floating markets, and lush green paddy fields.",
            longDescription: "Often called the 'Venice of the East,' Barisal is a land of rivers. Experience the unique floating markets, enjoy boat rides through scenic backwaters, and witness the lush, green landscapes that make this division a photographer's paradise.",
            imageUrl: "img/divisions/barisal-card.jpg",
        },
        sylhet: {
            title: "Sylhet",
            description: "A region of stunning natural beauty, with rolling tea gardens, rainforests, and the picturesque Jaflong and Ratargul Swamp Forest.",
            longDescription: "Sylhet is blessed with breathtaking natural beauty. From the rolling green carpets of its vast tea gardens to the crystal-clear waters of Lalakhal and the stone collection activities at Jaflong, it's a haven for nature lovers.",
            imageUrl: "img/divisions/sylhet-card.jpg",
        },
        rangpur: {
            title: "Rangpur",
            description: "A northern division with a rich cultural heritage, historical landmarks, and significant agricultural production.",
            longDescription: "Rangpur is steeped in history, home to Kantajew Temple, one of the most magnificent terracotta temples in Bangladesh, and the grand Tajhat Palace. It offers a glimpse into the region's rich cultural and architectural past.",
            imageUrl: "img/divisions/rangpur-card.jpg",
        },
        mymensingh: {
            title: "Mymensingh",
            description: "A division rich in folk culture and history, situated on the banks of the Brahmaputra River with a serene, rural landscape.",
            longDescription: "Located on the banks of the old Brahmaputra river, Mymensingh is known for its rich folk culture and historical significance. Explore the scenic rural landscapes and discover the heritage of the zamindars who once ruled the area.",
            imageUrl: "img/divisions/mymensingh-card.jpg",
        },
    }
});

    Alpine.store('auth', {
        user: JSON.parse(localStorage.getItem('user')),
        token: localStorage.getItem('token'),
        toursNeedRefresh: false,
        get check() {
            return !!this.user;
        },
        login(userData, token) {
            this.user = userData;
            this.token = token;
            localStorage.setItem('user', JSON.stringify(userData));
            localStorage.setItem('token', token);
        },
        logout() {
            this.user = null;
            this.token = null;
            localStorage.removeItem('user');
            localStorage.removeItem('token');
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {

    createLeafletMap({
        elementId: 'contact-map',
        location: { lat: 23.81436, lng: 90.41942 },
        zoom: 15,
        title: 'TravelGenie Headquarters'
    });
    const header = document.querySelector('header');
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('header-scrolled');
            } else {
                header.classList.remove('header-scrolled');
            }
        });
    }
    if (document.getElementById('background-video')) {
        try {
            const backgroundVideoPlayer = videojs('background-video');
        } catch (err) {
            console.warn('Video.js init warning:', err);
        }
    }
if (document.querySelector('.division-slider')) {
    try {
        const swiper = new Swiper('.division-slider', {
            loop: true,
            slidesPerView: 'auto',
            centeredSlides: true,
            spaceBetween: 30,
            navigation: {
                nextEl: '.main-nav-next',
                prevEl: '.main-nav-prev',
            },
        });

     
        swiper.on('slideChangeTransitionEnd', () => {
            const activeSlide = swiper.slides[swiper.activeIndex];
            const divisionId = activeSlide ? activeSlide.dataset.division : null;

            if (divisionId) {
            
                const event = new CustomEvent('division-changed', {
                    detail: { divisionId: divisionId }
                });
                window.dispatchEvent(event);
            }
        });

        window.dispatchEvent(new CustomEvent('division-changed', {
            detail: { divisionId: 'dhaka' }
        }));

    } catch (err) {
        console.warn('Swiper init warning:', err);
    }
}
    const servicesContainer = document.getElementById('services-container');
    if (servicesContainer) {
        const serviceNavButtons = document.querySelectorAll('.service-nav-btn');
        const serviceSlides = document.querySelectorAll('#services-container > div[id^="service-"]');
        if (serviceNavButtons.length > 0) {
            serviceNavButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const targetId = button.dataset.target;
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        servicesContainer.scrollTo({ left: targetElement.offsetLeft, behavior: 'smooth' });
                    }
                });
            });
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const visibleServiceId = entry.target.id;
                        serviceNavButtons.forEach(btn => btn.classList.remove('active-service-btn'));
                        const activeButton = document.querySelector(`.service-nav-btn[data-target="#${visibleServiceId}"]`);
                        if (activeButton) activeButton.classList.add('active-service-btn');
                    }
                });
            }, { root: servicesContainer, threshold: 0.5 });
            serviceSlides.forEach(slide => observer.observe(slide));
        }
    }
});

function createLeafletMap(options) {
    
    const mapElement = document.getElementById(options.elementId);
    if (!mapElement) return;

    if (mapElement._leaflet_id) {
        mapElement._leaflet_id = null;
    }

    const map = L.map(options.elementId).setView([options.location.lat, options.location.lng], options.zoom);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    L.marker([options.location.lat, options.location.lng]).addTo(map)
        .bindPopup(options.title)
        .openPopup();

    return map;
}
function toursComponent() {
    return {
        allTours: [],
        isLoading: true,
        search: '',
        sort: 'popular',
        filters: { destination: 'any', category: 'any', duration: 'any', minRating: 0 },
        wishlist: JSON.parse(localStorage.getItem('wishlist') || '[]'),
        currentPage: 1,
        perPage: 6,
        isTourModalOpen: false,
        currentTour: null,
        map: null,
        bookingStatus: '',
        bookingDate: '',
        numAdults: 1,
        numChildren: 0,
        paymentProcessing: false,
        paymentStep: 'details',
        currentBookingId: null,
        cardDetails: { number: '', expiry: '', cvv: '' },

        init() {
    this.fetchTours().then(() => {

        const tourIdToView = localStorage.getItem('viewTourId');

        if (tourIdToView) {
            const tourToShow = this.allTours.find(t => t.id == tourIdToView);
            
            if (tourToShow) {
                this.openTourModal(tourToShow);
            }
            localStorage.removeItem('viewTourId');
        }
    });

    this.$watch(() => Alpine.store('auth').toursNeedRefresh, (needsRefresh) => {
        if (needsRefresh) {
            this.fetchTours();
            Alpine.store('auth').toursNeedRefresh = false;
        }
    });
},
        fetchTours() {
    this.isLoading = true;
    return fetch('http://127.0.0.1:8000/api/tours')
        .then(res => res.json())
        .then(data => { this.allTours = data; })
        .catch(error => console.error('Error fetching tours:', error))
        .finally(() => { this.isLoading = false; });
},
        get totalPrice() {
            if (!this.currentTour) return 0;
            return (this.currentTour.price * this.numAdults) + ((this.currentTour.price / 2) * this.numChildren);
        },
        get filteredTours() {
            let tours = [...this.allTours];
            if (this.search.trim()) { tours = tours.filter(t => (t.title + ' ' + t.location + ' ' + t.highlights.join(' ')).toLowerCase().includes(this.search.toLowerCase())); }
            if (this.filters.destination !== 'any') { tours = tours.filter(t => t.location === this.filters.destination); }
            if (this.filters.category !== 'any') { tours = tours.filter(t => t.category === this.filters.category); }
            if (this.filters.minRating > 0) { tours = tours.filter(t => t.rating >= this.filters.minRating); }
            if (this.filters.duration !== 'any') {
                const d = this.filters.duration;
                if (d === '1') tours = tours.filter(t => t.duration === 1);
                else if (d === '2-3') tours = tours.filter(t => t.duration >= 2 && t.duration <= 3);
                else if (d === '4-7') tours = tours.filter(t => t.duration >= 4 && t.duration <= 7);
                else if (d === '7+') tours = tours.filter(t => t.duration >= 7);
            }
            switch (this.sort) {
                case 'price-asc': tours.sort((a, b) => a.price - b.price); break;
                case 'price-desc': tours.sort((a, b) => b.price - a.price); break;
                case 'duration-asc': tours.sort((a, b) => a.duration - b.duration); break;
                case 'rating-desc': tours.sort((a, b) => b.rating - a.rating); break;
                default: tours.sort((a, b) => b.rating - a.rating);
            }
            if (this.currentPage > Math.ceil(tours.length / this.perPage)) { this.currentPage = 1; }
            return tours;
        },
        get paginatedTours() {
            const start = (this.currentPage - 1) * this.perPage;
            const end = start + this.perPage;
            return this.filteredTours.slice(start, end);
        },
        get totalPages() {
            return Math.ceil(this.filteredTours.length / this.perPage) || 1;
        },
        clearFilters() {
            this.search = '';
            this.sort = 'popular';
            this.filters = { destination: 'any', category: 'any', duration: 'any', minRating: 0 };
            this.currentPage = 1;
        },
        async toggleWishlist(tourId) {
    if (!Alpine.store('auth').check) {
        document.querySelector('body').__x.$data.isLoginOpen = true;
        return;
    }

    const token = Alpine.store('auth').token;
    try {
        const response = await fetch(`http://127.0.0.1:8000/api/wishlist/${tourId}`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);

        if (result.status === 'added') {
            if (!this.wishlist.includes(tourId)) this.wishlist.push(tourId);
        } else if (result.status === 'removed') {
            this.wishlist = this.wishlist.filter(id => id !== tourId);
        }
        localStorage.setItem('wishlist', JSON.stringify(this.wishlist));

    } catch (error) {
        alert(`Error: ${error.message}`);
    }
},
        openTourModal(tour) {
            this.currentTour = tour;
            this.isTourModalOpen = true;
            this.bookingStatus = ''; this.bookingDate = ''; this.numAdults = 1; this.numChildren = 0;
            this.paymentProcessing = false; this.paymentStep = 'details'; this.currentBookingId = null;
            this.cardDetails = { number: '', expiry: '', cvv: '' };
            this.$nextTick(() => {
                if (this.currentTour.coords) {
                    createLeafletMap({ elementId: 'tour-map', location: this.currentTour.coords, zoom: 13, title: this.currentTour.title });
                }
            });
        },
        
        closeTourModal() {
            this.isTourModalOpen = false;
            if (this.map) { this.map.remove(); this.map = null; }
        },

       
        handleBookingAttempt() {
    if (Alpine.store('auth').check && Alpine.store('auth').user.role === 'traveler') {
        this.initiateBooking();
    } else {
        this.bookingStatus = 'Error: You must be logged in as a Traveler to book.';
    }
},
        async initiateBooking() {
            if (!Alpine.store('auth').check) {
                this.bookingStatus = 'You must be logged in to book.';
                document.querySelector('body').__x.$data.isLoginOpen = true;
                return;
            }
            this.paymentProcessing = true; this.bookingStatus = 'Saving your spot...';
            const bookingData = { tour_id: this.currentTour.id, booking_date: this.bookingDate, num_adults: this.numAdults, num_children: this.numChildren, total_price: this.totalPrice };
            try {
                const response = await fetch('http://127.0.0.1:8000/api/bookings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': `Bearer ${Alpine.store('auth').token}` },
                    body: JSON.stringify(bookingData)
                });
                const result = await response.json();
                if (!response.ok) throw new Error(result.message);
                this.currentBookingId = result.booking.id;
                this.paymentStep = 'payment';
                this.bookingStatus = '';
            } catch (error) {
                this.bookingStatus = `Error: ${error.message}`;
            } finally {
                this.paymentProcessing = false;
            }
        },
        async confirmPayment() {

    if (!Alpine.store('auth').check) {
        this.bookingStatus = 'Error: You have been logged out. Please log in again to complete your booking.';
        return;
    }

    this.paymentProcessing = true;
    this.bookingStatus = 'Processing...';
    const token = Alpine.store('auth').token;

    try {
        const paymentResponse = await fetch(`http://127.0.0.1:8000/api/bookings/${this.currentBookingId}/simulate-payment`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
        });
        
        const result = await paymentResponse.json();

        if (!paymentResponse.ok) {
            if (paymentResponse.status === 401) {
                Alpine.store('auth').logout();
                throw new Error('Your session has expired. Please log in again.');
            }
            throw new Error(result.message || 'Payment confirmation failed.');
        }

        this.bookingStatus = result.message;
        setTimeout(() => { this.closeTourModal(); }, 2500);

    } catch (error) {
        this.bookingStatus = `Error: ${error.message}`;
    } finally {
        this.paymentProcessing = false;
    }
},
        skipPayment() {

    if (!Alpine.store('auth').check) {
        this.bookingStatus = 'Error: You have been logged out. Please log in again.';
        return;
    }

    this.bookingStatus = 'Your booking is pending. You can complete the payment from your dashboard.';
    setTimeout(() => { this.closeTourModal(); }, 2500);
},
        formatPrice(n) { return '৳' + n.toLocaleString(); },
        renderStars(rating) {
    if (!rating && rating !== 0) {
        return '<span class="text-gray-400 text-sm">No Ratings</span>';
    }
    return '★'.repeat(Math.round(rating)) + ' <span class="text-gray-400 text-sm">' + parseFloat(rating).toFixed(1) + '</span>';
}
    };
}
function admin() {
    return {
        users: [],
        tours: [],
        bookings: [],
        isLoading: { users: true, tours: true, bookings: true },
        blogs: [],
        isBlogFormVisible: false,
        blogFormTitle: '',
        blogForm: {},
        blogImageFiles: [],
        blogImagePreviews: [],
        init() {
            if (Alpine.store('auth').user?.role !== 'administrator') {
                alert('Access Denied: You must be an administrator to view this page.');
                window.location.href = 'index.html';
                return;
            }
            this.fetchUsers();
            this.fetchTours();
            this.fetchBookings();
            this.fetchBlogs();
        },

        async fetchUsers() {
            this.isLoading.users = true;
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch('http://127.0.0.1:8000/api/admin/users', {
                    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
                });
                if (!response.ok) throw new Error('Failed to fetch users.');
                this.users = await response.json();
            } catch (error) {
                alert(error.message);
            } finally {
                this.isLoading.users = false;
            }
        },
        async updateUserRole(user, newRole) {
    if (!confirm(`Are you sure you want to change ${user.name}'s role to ${newRole}?`)) {
        event.target.value = user.role;
        return;
    }

    const token = Alpine.store('auth').token;
    try {
        const response = await fetch(`http://127.0.0.1:8000/api/admin/users/${user.id}/role`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ role: newRole })
        });
        if (!response.ok) {
            throw new Error('Failed to update role.');
        }
        const updatedUser = await response.json();
        
        user.role = updatedUser.user.role; 
        
        alert('User role updated successfully!');
    } catch (error) {
        console.error(error);
        alert(error.message);
        event.target.value = user.role; 
    }
},
async deleteUser(user) {
    if (!confirm(`Are you sure you want to permanently delete the user "${user.name}"? This action cannot be undone.`)) {
        return;
    }

    const token = Alpine.store('auth').token;
    try {
        const response = await fetch(`http://127.0.0.1:8000/api/admin/users/${user.id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            }
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || 'Failed to delete user.');
        }
        
        alert('User deleted successfully!');
        
        this.users = this.users.filter(u => u.id !== user.id);

    } catch(error) {
        alert(`Error: ${error.message}`);
    }
},
        async fetchTours() {
            this.isLoading.tours = true;
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch('http://127.0.0.1:8000/api/admin/tours', {
                    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
                });
                if (!response.ok) throw new Error('Failed to fetch tours.');
                this.tours = await response.json();
            } catch (error) {
                alert(error.message);
            } finally {
                this.isLoading.tours = false;
            }
        },
        
        async fetchBookings() {
            this.isLoading.bookings = true;
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch('http://127.0.0.1:8000/api/admin/bookings', {
                    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
                });
                if (!response.ok) throw new Error('Failed to fetch bookings.');
                this.bookings = await response.json();
            } catch (error) {
                alert(error.message);
            } finally {
                this.isLoading.bookings = false;
            }
        },
        async deleteTour(tourId) {
    if (!confirm('Are you sure you want to permanently delete this tour? This will also delete all associated bookings.')) {
        return;
    }

    const token = Alpine.store('auth').token;
    try {
        const response = await fetch(`http://127.0.0.1:8000/api/business/tours/${tourId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
        });

        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || 'Failed to delete tour.');
        }
        
        alert('Tour deleted successfully!');
        
        this.tours = this.tours.filter(t => t.id !== tourId);

    } catch(error) {
        alert(`Error: ${error.message}`);
    }
},
        async updateBookingStatus(booking, newStatus) {
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch(`http://127.0.0.1:8000/api/admin/bookings/${booking.id}/status`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': `Bearer ${token}` },
                    body: JSON.stringify({ status: newStatus })
                });
                if (!response.ok) throw new Error('Failed to update booking status.');
                const updatedBooking = await response.json();
                booking.status = updatedBooking.booking.status;
                alert('Booking status updated!');
            } catch (error) {
                alert(error.message);
                event.target.value = booking.status;
            }
        },
        async deleteBooking(bookingId) {
    if (!confirm('Are you sure you want to permanently delete this booking?')) {
        return;
    }

    const token = Alpine.store('auth').token;
    try {
        const response = await fetch(`http://127.0.0.1:8000/api/admin/bookings/${bookingId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
        });

        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || 'Failed to delete booking.');
        }
        
        alert('Booking deleted successfully!');

        this.bookings = this.bookings.filter(b => b.id !== bookingId);

    } catch(error) {
        alert(`Error: ${error.message}`);
    }
},
async fetchBlogs() {
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch('http://127.0.0.1:8000/api/admin/blogs', { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } });
                if (!response.ok) throw new Error('Failed to fetch blogs.');
                this.blogs = await response.json();
            } catch (error) { alert(error.message); }
        },

        openBlogCreateForm() {
            this.blogFormTitle = 'Create New Blog Post';
            this.blogForm = { title: '', division: '', author: '', date: new Date().toISOString().slice(0, 10), content: '' };
            this.blogImageFiles = [];
            this.blogImagePreviews = [];
            this.isBlogFormVisible = true;
        },

        closeBlogForm() {
            this.isBlogFormVisible = false;
        },

        handleBlogImageSelect(event) {
            this.blogImageFiles = Array.from(event.target.files);
            this.blogImagePreviews = [];
            for (const file of this.blogImageFiles) {
                const reader = new FileReader();
                reader.onload = (e) => this.blogImagePreviews.push(e.target.result);
                reader.readAsDataURL(file);
            }
        },

async saveBlogPost() {
    if (!this.blogForm || typeof this.blogForm !== 'object') {
        alert('Error: Form data is missing. Please try again.');
        return;
    }

    const token = Alpine.store('auth').token;
    const formData = new FormData();

    for (const key in this.blogForm) {
        formData.append(key, this.blogForm[key]);
    }

    if (this.blogImageFiles.length > 0) {
        for (const file of this.blogImageFiles) {
            formData.append('images[]', file);
        }
    } else {
        formData.append('images', '');
    }

    try {
        const response = await fetch(`http://127.0.0.1:8000/api/admin/blogs`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            },
            body: formData
        });

        const result = await response.json();

        if (!response.ok) {
            const errorMessages = Object.values(result.errors || { error: [result.message] }).flat().join('\n');
            throw new Error(errorMessages || 'An unknown error occurred.');
        }

        alert('Blog post saved successfully!');
        this.closeBlogForm();
        await this.fetchBlogs();

    } catch (error) {
        alert(`Error: ${error.message}`);
    }
},

        async deleteBlogPost(postId) {
            if (!confirm('Are you sure you want to delete this blog post?')) return;
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch(`http://127.0.0.1:8000/api/admin/blogs/${postId}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } });
                if (!response.ok) throw new Error('Failed to delete post.');
                alert('Blog post deleted.');
                this.blogs = this.blogs.filter(p => p.id !== postId);
            } catch (error) { alert(`Error: ${error.message}`); }
        }

    }
    }

function dashboardComponent() {
    return {
        user: Alpine.store('auth').user,
        isLoading: true,
        bookings: [],
        wishlist: [],
        isLoadingWishlist: true,
        isReviewModalOpen: false,
        currentReviewBooking: null,
        reviewRating: 0,
        reviewComment: '',
        reviewStatus: '',
        profileDetails: { name: '', email: '' },
        passwordDetails: { current_password: '', new_password: '', new_password_confirmation: '' },
        profileStatus: '',
        passwordStatus: '',

        myTours: [],
        isFormVisible: false,
        formTitle: '',
        form: {},
        imageFiles: [],
        imagePreviews: [],

init() {
    if (!this.user) {
        window.location.href = 'index.html';
        return;
    }
    if (this.user.role === 'traveler') {
        document.title = "My Dashboard - TravelGenie";
        this.profileDetails.name = this.user.name;
        this.profileDetails.email = this.user.email;
        this.fetchBookings();
        this.fetchWishlist();
    } else if (this.user.role === 'business_owner') {
        document.title = "Business Dashboard - TravelGenie";
        this.fetchMyTours();
    } else {
        this.isLoading = false;
    }
},

        logout() {
            Alpine.store('auth').logout();
            window.location.href = 'index.html';
        },
        initMapPicker() {
    this.$nextTick(() => {
        const dhaka = { lat: 23.8103, lng: 90.4125 };
        this.mapPicker = createLeafletMap({
            elementId: 'map-picker',
            location: dhaka,
            zoom: 12,
            title: 'Drag me to the tour location!'
        });

        this.marker = L.marker(dhaka, { draggable: true }).addTo(this.mapPicker);
        
        this.marker.on('dragend', () => {
            const newPosition = this.marker.getLatLng();
            this.form.coords = { lat: newPosition.lat, lng: newPosition.lng };
        });
        
        this.form.coords = { lat: dhaka.lat, lng: dhaka.lng };
    });
},

        async fetchBookings() {
            this.isLoading = true;
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch('http://127.0.0.1:8000/api/user/bookings', { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } });
                if (!response.ok) {
                    if (response.status === 401) { Alpine.store('auth').logout(); window.location.href = 'index.html'; }
                    throw new Error('Could not fetch bookings.');
                }
                this.bookings = await response.json();
            } catch (error) { console.error('Error fetching bookings:', error); } 
            finally { this.isLoading = false; }
        },
        async fetchWishlist() {
            this.isLoadingWishlist = true;
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch('http://127.0.0.1:8000/api/wishlist', { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } });
                if (!response.ok) throw new Error('Could not fetch wishlist.');
                this.wishlist = await response.json();
            } catch (error) { console.error('Error fetching wishlist:', error); } 
            finally { this.isLoadingWishlist = false; }
        },
        viewTourFromWishlist(tourId) { localStorage.setItem('viewTourId', tourId); window.location.href = 'index.html#tours-section'; },
        openReviewModal(booking) { this.currentReviewBooking = booking; this.reviewRating = 0; this.reviewComment = ''; this.reviewStatus = ''; this.isReviewModalOpen = true; },
        closeReviewModal() { this.isReviewModalOpen = false; },
        async submitReview() {
            this.reviewStatus = 'Submitting...';
            const token = Alpine.store('auth').token;
            const bookingId = this.currentReviewBooking.id;
            try {
                const response = await fetch(`http://127.0.0.1:8000/api/bookings/${bookingId}/reviews`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ rating: this.reviewRating, comment: this.reviewComment }) });
                const result = await response.json();
                if (!response.ok) { throw new Error(result.message || 'Could not submit review.'); }
                this.reviewStatus = result.message;
                this.currentReviewBooking.reviewed = true;
                Alpine.store('auth').toursNeedRefresh = true;
                setTimeout(() => { this.closeReviewModal(); }, 2000);
            } catch (error) { this.reviewStatus = `Error: ${error.message}`; }
        },
        async updateProfile() {
            this.profileStatus = 'Updating...';
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch('http://127.0.0.1:8000/api/user/profile', { method: 'PUT', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify(this.profileDetails) });
                const result = await response.json();
                if (!response.ok) { throw new Error(result.message || 'Could not update profile.'); }
                this.profileStatus = result.message;
                Alpine.store('auth').user.name = result.user.name;
                Alpine.store('auth').user.email = result.user.email;
            } catch (error) { this.profileStatus = `Error: ${error.message}`; }
        },
        async changePassword() {
            this.passwordStatus = 'Changing...';
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch('http://127.0.0.1:8000/api/user/password', { method: 'PUT', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify(this.passwordDetails) });
                const result = await response.json();
                if (!response.ok) { throw new Error(result.message || 'Could not change password.'); }
                this.passwordStatus = result.message;
                this.passwordDetails = { current_password: '', new_password: '', new_password_confirmation: '' };
            } catch (error) { this.passwordStatus = `Error: ${error.message}`; }
        },

async cancelBooking(booking) {
    if (!confirm(`Are you sure you want to cancel the booking for "${booking.user.name}"?`)) {
        return;
    }

    const token = Alpine.store('auth').token;
    try {
        const response = await fetch(`http://127.0.0.1:8000/api/business/bookings/${booking.id}/cancel`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
        });

        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || 'Failed to cancel booking.');
        }

        booking.status = 'cancelled';
        alert('Booking cancelled successfully!');

    } catch (error) {
        alert(`Error: ${error.message}`);
    }
},
        async cancelBooking(booking) {
            if (!confirm('Are you sure you want to cancel this booking?')) return;
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch(`http://127.0.0.1:8000/api/bookings/${booking.id}/cancel`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': `Bearer ${token}` } });
                const result = await response.json();
                if (!response.ok) { throw new Error(result.message || 'Could not cancel booking.'); }
                booking.status = 'cancelled';
                alert(result.message);
            } catch (error) { alert(`Error: ${error.message}`); }
        },
        
        async fetchMyTours() {
            this.isLoading = true;
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch('http://127.0.0.1:8000/api/business/tours', { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } });
                if (!response.ok) {
                    if (response.status === 401) { Alpine.store('auth').logout(); window.location.href = 'index.html'; }
                    throw new Error('Could not fetch your tours.');
                }
                this.myTours = await response.json();
            } catch (error) {
                alert(error.message);
            } finally {
                this.isLoading = false;
            }
        },


handleFileSelect(event) {
    const file = event.target.files[0];

    if (file) {
        this.imageFiles = [file];

        const reader = new FileReader();
        reader.onload = (e) => {
            this.imagePreviews = [e.target.result];
        };
        reader.readAsDataURL(file);
    } else {
        this.imageFiles = [];
        this.imagePreviews = [];
    }
},

        openCreateForm() {
    this.formTitle = 'Create a New Tour';
    this.form = {
        title: '', location: '', category: '', 
        duration: 1, price: 1000, rating: 0, 
        highlights: '', 
        coords: { lat: '', lng: '' }
    };
    this.imageFiles = [];
    this.imagePreviews = [];
    this.isFormVisible = true;
},

        closeForm() {
    this.isFormVisible = false;
},

        async saveTour() {
    const token = Alpine.store('auth').token;
    const url = 'http://127.0.0.1:8000/api/business/tours';

    const formData = new FormData();

    formData.append('title', this.form.title);
    formData.append('location', this.form.location);
    formData.append('category', this.form.category);
    formData.append('duration', this.form.duration);
    formData.append('price', this.form.price);
    formData.append('rating', this.form.rating);
    
    formData.append('highlights', JSON.stringify(this.form.highlights.split('\n').map(s => s.trim()).filter(s => s)));
    formData.append('coords', JSON.stringify(this.form.coords));
    if (this.imageFiles.length > 0) {
    formData.append('image', this.imageFiles[0]);
}
    for (const file of this.imageFiles) {
        formData.append('images[]', file);
    }

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json',
            },
            body: formData
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            const errorMessages = Object.values(errorData.errors || {error:[errorData.message]}).flat().join('\n');
            throw new Error(errorMessages || 'Failed to save tour.');
        }
        
        alert('Tour saved successfully!');
        this.closeForm();
        await this.fetchMyTours();
        Alpine.store('auth').toursNeedRefresh = true;
    } catch(error) {
        alert(`Error:\n${error.message}`);
    }
},

        async deleteTour(tourId) {
            if (!confirm('Are you sure you want to permanently delete this tour?')) return;
            const token = Alpine.store('auth').token;
            try {
                const response = await fetch(`http://127.0.0.1:8000/api/business/tours/${tourId}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } });
                const result = await response.json();
                if (!response.ok) { throw new Error(result.message); }
                alert('Tour deleted successfully!');
                this.myTours = this.myTours.filter(t => t.id !== tourId);
            } catch(error) { alert(`Error: ${error.message}`); }
        },

        formatPrice(n) { return '৳' + (n ? n.toLocaleString() : '0'); }
    }
}