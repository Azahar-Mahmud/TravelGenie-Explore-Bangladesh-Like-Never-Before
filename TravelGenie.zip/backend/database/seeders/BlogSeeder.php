<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Blog;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Http\File as HttpFile;

class BlogSeeder extends Seeder
{
    public function run(): void
    {
        Blog::truncate();
        Storage::disk('public')->deleteDirectory('blogs');
        $sourceImagePath = database_path('seeders/images/Lalbagh-Fort-Shutterstock.jpg');

        if (File::exists($sourceImagePath)) {
            $path = Storage::disk('public')->putFile('blogs', new HttpFile($sourceImagePath));
            $imageUrl = Storage::disk('public')->url($path);
            Blog::create([
                'title' => 'Dhaka Division – The Vibrant Heart of Bangladesh',
                'division' => 'dhaka',
                'author' => 'TravelGenie Admin',
                'date' => '2025-09-01',
                'images' => [$imageUrl],
                'content' => '<p>Dhaka, the capital of Bangladesh, is not only the country’s political and economic center but also a hub of culture and history. The city is famous for its bustling markets, colonial architecture, and rich heritage.</p><p class="mt-4">Historical sites like Lalbagh Fort, Ahsan Manzil, and Star Mosque showcase Dhaka’s Mughal and colonial past. For modern leisure, Bashundhara City Mall, Jamuna Future Park, and numerous cafes provide entertainment options. Outside the city, explore Gazipur’s eco-parks and Narayanganj’s traditional weaving industries. Street food lovers can savor fuchka, chotpoti, and biryani. Dhaka Division perfectly blends urban energy with historical charm, making it a must-visit.</p>',
            ]);
        } else {
            $this->command->error("Could not find the seeder image at: " . $sourceImagePath);
        }
    }
}