<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Tour;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Http\File as HttpFile;

class BusinessOwnerSeeder extends Seeder
{
    public function run(): void
    {
        $businessOwner = User::create([
            'name' => 'Business Owner',
            'email' => 'business@user.com',
            'password' => Hash::make('password'),
            'role' => 'business_owner',
            'security_question' => 'Company name?',
            'security_answer' => Hash::make('travelgenie'),
        ]);

        $sourceImagePath = database_path('seeders/images/sundarbans_tour.jpg');
        $imageUrl = null;

        if (File::exists($sourceImagePath)) {
            $path = Storage::disk('public')->putFile('tours', new HttpFile($sourceImagePath));
            $imageUrl = Storage::disk('public')->url($path);
        } else {
            $this->command->warn("Could not find seeder image for tour at: " . $sourceImagePath);
        }

        if ($businessOwner && $imageUrl) {
            Tour::create([
                'user_id' => $businessOwner->id,
                'title' => 'Sundarbans Mangrove Safari',
                'location' => 'Khulna',
                'category' => 'wildlife',
                'duration' => 3,
                'price' => 18000.00,
                'rating' => 0.0,
                'image_url' => $imageUrl,
                'highlights' => ['Royal Bengal Tiger sightings', 'Boat cruises through dense canals', 'Visit local fishing villages'],
                'itinerary' => [],
                'coords' => ['lat' => 22.3167, 'lng' => 89.5667],
            ]);
        }
    }
}