<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
        TourSeeder::class,
        BlogSeeder::class,
        BusinessOwnerSeeder::class,
    ]);

        User::create([
            'name' => 'Admin User',
            'email' => 'admin@user.com',
            'password' => Hash::make('password'),
            'role' => 'administrator',
            'security_question' => 'Favourite primary color?',
            'security_answer' => Hash::make('blue'),
        ]);

        User::create([
            'name' => 'Traveler',
            'email' => 'traveler@user.com',
            'password' => Hash::make('password'),
            'role' => 'traveler',
            'security_question' => 'Favorite travel spot?',
            'security_answer' => Hash::make('beach'),
        ]);

        User::create([
            'name' => 'Business Owner',
            'email' => 'business@user.com',
            'password' => Hash::make('password'),
            'role' => 'business_owner',
            'security_question' => 'Company name?',
            'security_answer' => Hash::make('travelgenie'),
        ]);
    }
}
