<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    
    public function up(): void
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id(); 
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            
            $table->foreignId('tour_id')->constrained()->onDelete('cascade');

            
            $table->date('booking_date');
            $table->integer('num_adults');
            $table->integer('num_children')->default(0);
            $table->decimal('total_price', 10, 2);

            
            $table->string('customer_name')->default('Guest User'); 
            $table->string('customer_email')->default('guest@example.com');

            
            $table->string('status')->default('pending'); 

            $table->timestamps(); 
        });
    }

    
    public function down(): void
    {
        Schema::dropIfExists('bookings');
    }
};
