<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AdminController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PasswordResetController;
use App\Http\Controllers\Api\BlogController;
use App\Http\Controllers\Api\BookingController;
use App\Http\Controllers\Api\ReviewController;
use App\Http\Controllers\Api\TourController;
use App\Http\Controllers\Api\WishlistController;


Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/password/verify-answer', [PasswordResetController::class, 'verifySecurityAnswer']);
Route::post('/password/reset-with-token', [PasswordResetController::class, 'resetPasswordWithToken']);
Route::get('/tours', [TourController::class, 'index']);
Route::get('/blogs/{division}', [BlogController::class, 'showByDivision']);


Route::middleware('auth:sanctum')->group(function () {

    Route::put('/user/profile', [AuthController::class, 'updateProfile']);
    Route::put('/user/password', [AuthController::class, 'changePassword']);
    Route::get('/user', fn(Request $request) => $request->user());
    Route::post('/logout', [AuthController::class, 'logout']);

    Route::post('/bookings', [BookingController::class, 'store']);
    Route::post('/bookings/{booking}/cancel', [BookingController::class, 'cancel']);
    Route::get('/user/bookings', [BookingController::class, 'userBookings']);
    Route::post('/bookings/{booking}/simulate-payment', [BookingController::class, 'simulatePayment']);

    Route::post('/bookings/{booking}/reviews', [ReviewController::class, 'store']);

    Route::get('/wishlist', [WishlistController::class, 'index']);
    Route::post('/wishlist/{tour}', [WishlistController::class, 'toggle']);
});

Route::middleware(['auth:sanctum', 'admin'])->prefix('admin')->group(function () {

    Route::get('/users', [AdminController::class, 'getUsers']);
    Route::put('/users/{user}/role', [AdminController::class, 'updateUserRole']);
    Route::delete('/users/{user}', [AdminController::class, 'destroyUser']);

    Route::get('/tours', [AdminController::class, 'getAllTours']);
    Route::get('/bookings', [AdminController::class, 'getAllBookings']);
    Route::put('/bookings/{booking}/status', [AdminController::class, 'updateBookingStatus']);
    Route::delete('/bookings/{booking}', [AdminController::class, 'destroyBooking']);

    Route::get('/blogs', [BlogController::class, 'index']);
    Route::post('/blogs', [BlogController::class, 'store']);
    Route::delete('/blogs/{blog}', [BlogController::class, 'destroy']);
});

Route::middleware(['auth:sanctum', 'business-owner'])->prefix('business')->group(function () {
    Route::get('/tours', [TourController::class, 'myTours']);
    Route::post('/tours', [TourController::class, 'store']);
    Route::put('/tours/{tour}', [TourController::class, 'update']);
    Route::delete('/tours/{tour}', [TourController::class, 'destroy']);
});
